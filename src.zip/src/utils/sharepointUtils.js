import { SHAREPOINT_CONFIG } from '../config/sharepoint.config';
import { SHAREPOINT_PATHS } from '../config/sharepointPaths';
import { spLog, spLogDigestCache } from './spAppLog';

const requestDigestCache = new Map();
const CACHE_EXPIRATION_MS = 25 * 60 * 1000; // 25 minutes (SharePoint digest ~30m)

const IMAGE_BASE_FOLDER = import.meta.env.VITE_SP_IMAGE_BASE_FOLDER || SHAREPOINT_PATHS.imageBaseFolderServerRelativeUrl;
const RAW_SITE_API_ROOT =
    import.meta.env.VITE_SP_SITE_API_ROOT ||
    import.meta.env.VITE_SP_SITE_ROOT ||
    SHAREPOINT_PATHS.siteApiRoot;
const ODATA_ACCEPT = 'application/json;odata=verbose';
const ODATA_CONTENT_TYPE = 'application/json;odata=verbose';
const ROOT_CACHE_KEY = '__root__';
const KNOWN_LIBRARY_SEGMENTS = new Set([
    'siteassets',
    'shared documents',
    'shared%20documents',
    'documents',
    'style library',
    'sitepages',
    'site pages',
    'lists',
]);

const normalizeServerRelativeUrl = (value) => {
    const raw = String(value ?? '').trim();
    if (!raw) return '';
    return raw.startsWith('/') ? raw : `/${raw}`;
};

const splitPathSegments = (path) => normalizeServerRelativeUrl(path).split('/').filter(Boolean);

const decodeSafe = (value) => {
    try {
        return decodeURIComponent(String(value ?? ''));
    } catch {
        return String(value ?? '');
    }
};

const isKnownLibrarySegment = (segment) => {
    const raw = String(segment ?? '').trim().toLowerCase();
    if (!raw) return false;
    const decoded = decodeSafe(raw).toLowerCase();
    return KNOWN_LIBRARY_SEGMENTS.has(raw) || KNOWN_LIBRARY_SEGMENTS.has(decoded);
};

const toPathname = (urlOrPath) => {
    const raw = String(urlOrPath ?? '').trim();
    if (!raw) return '';

    if (/^https?:\/\//i.test(raw)) {
        try {
            return normalizeServerRelativeUrl(new URL(raw).pathname || '/');
        } catch {
            return '';
        }
    }

    return normalizeServerRelativeUrl(raw);
};

const toRequestUrl = (urlOrPath) => {
    const raw = String(urlOrPath ?? '').trim();
    if (!raw) {
        throw new Error('Missing SharePoint URL');
    }

    if (/^https?:\/\//i.test(raw)) {
        return raw;
    }

    return normalizeServerRelativeUrl(raw);
};

const responseTextSafe = async (response) => {
    try {
        return await response.text();
    } catch {
        return '';
    }
};

const summarizeErrorText = (text) => String(text ?? '').replace(/\s+/g, ' ').trim().slice(0, 320);

const splitServerRelativeFileUrl = (serverRelativeUrl) => {
    const fileServerRelativeUrl = toPathname(serverRelativeUrl);
    const requestUrl = toRequestUrl(serverRelativeUrl);

    const lastSlashIndex = fileServerRelativeUrl.lastIndexOf('/');
    if (lastSlashIndex <= 0 || lastSlashIndex === fileServerRelativeUrl.length - 1) {
        throw new Error(`Invalid server-relative file URL: "${serverRelativeUrl}"`);
    }

    return {
        requestUrl,
        fileServerRelativeUrl,
        folderServerRelativeUrl: fileServerRelativeUrl.slice(0, lastSlashIndex),
        fileName: fileServerRelativeUrl.slice(lastSlashIndex + 1),
    };
};

const extractSiteRootFromPath = (path) => {
    const normalizedPath = toPathname(path);
    const segments = splitPathSegments(normalizedPath);
    if (segments.length === 0) {
        return { siteRoot: '', siteSegmentsLength: 0 };
    }

    const first = segments[0].toLowerCase();

    if (first === 'sites' || first === 'teams') {
        let libraryIndex = -1;
        for (let i = 2; i < segments.length; i += 1) {
            if (isKnownLibrarySegment(segments[i])) {
                libraryIndex = i;
                break;
            }
        }

        if (libraryIndex !== -1) {
            return {
                siteRoot: `/${segments.slice(0, libraryIndex).join('/')}`,
                siteSegmentsLength: libraryIndex,
            };
        }

        if (segments.length >= 3) {
            return {
                siteRoot: `/${segments.slice(0, 3).join('/')}`,
                siteSegmentsLength: 3,
            };
        }

        return {
            siteRoot: `/${segments.slice(0, Math.min(2, segments.length)).join('/')}`,
            siteSegmentsLength: Math.min(2, segments.length),
        };
    }

    const libraryIndex = segments.findIndex((segment) => isKnownLibrarySegment(segment));
    if (libraryIndex > 0) {
        return {
            siteRoot: `/${segments.slice(0, libraryIndex).join('/')}`,
            siteSegmentsLength: libraryIndex,
        };
    }

    return { siteRoot: '', siteSegmentsLength: 0 };
};

const inferTopLevelSiteRoot = (value = '') => {
    const normalizedPath = toPathname(value);
    if (!normalizedPath) return '';

    const segments = splitPathSegments(normalizedPath);
    if (segments.length < 2) return '';

    const first = segments[0].toLowerCase();
    if (first !== 'sites' && first !== 'teams') return '';

    return `/${segments[0]}/${segments[1]}`;
};

const resolveApiSiteRoot = (value = '') => {
    const configured = toPathname(RAW_SITE_API_ROOT);
    if (configured) return configured;

    const normalizedPath = toPathname(value);
    if (!normalizedPath) return '';

    const apiMarker = '/_api/';
    const apiIndex = normalizedPath.indexOf(apiMarker);
    if (apiIndex >= 0) {
        const fromApiPath = normalizedPath.slice(0, apiIndex) || '';
        const topFromApiPath = inferTopLevelSiteRoot(fromApiPath);
        return topFromApiPath || fromApiPath;
    }

    const topLevel = inferTopLevelSiteRoot(normalizedPath);
    if (topLevel) return topLevel;

    const { siteRoot } = extractSiteRootFromPath(normalizedPath);
    return siteRoot || '';
};

const buildSiteApiUrl = (siteRoot, apiPath) => {
    const root = normalizeServerRelativeUrl(siteRoot || '');
    if (!root) return apiPath;
    return `${root}${apiPath}`;
};

const buildFolderCreationPlan = (folderServerRelativeUrl) => {
    const normalizedFolder = normalizeServerRelativeUrl(folderServerRelativeUrl);
    const segments = splitPathSegments(normalizedFolder);
    const extracted = extractSiteRootFromPath(normalizedFolder);
    const siteRoot = resolveApiSiteRoot(normalizedFolder) || extracted.siteRoot;
    const siteSegmentsLength = splitPathSegments(siteRoot).length;
    const folderSegments = segments.slice(siteSegmentsLength);

    return {
        siteRoot,
        folderSegments,
    };
};

const ensureSharePointFolder = async (folderServerRelativeUrl, digest, siteRoot) => {
    const endpoint = buildSiteApiUrl(siteRoot, '/_api/web/folders');
    const response = await fetch(endpoint, {
        method: 'POST',
        credentials: 'include',
        headers: {
            Accept: ODATA_ACCEPT,
            'Content-Type': ODATA_CONTENT_TYPE,
            'X-RequestDigest': digest,
        },
        body: JSON.stringify({
            __metadata: { type: 'SP.Folder' },
            ServerRelativeUrl: folderServerRelativeUrl,
        }),
    });

    if (response.ok || response.status === 409) {
        return;
    }

    const errorText = summarizeErrorText(await responseTextSafe(response));
    const alreadyExists = response.status === 500 && /already exists/i.test(errorText);
    if (alreadyExists) {
        return;
    }

    throw new Error(`Failed to create folder "${folderServerRelativeUrl}" (${response.status}): ${errorText}`);
};

const putTextFile = async (requestUrl, text, contentType) => {
    return fetch(requestUrl, {
        method: 'PUT',
        credentials: 'include',
        headers: {
            'Content-Type': contentType,
        },
        body: text,
    });
};

/**
 * For compatibility with existing services, this returns the fetchable file URL.
 * We intentionally use direct file URL reads/writes (GET/PUT), not _api/$value.
 */
export const buildFileValueEndpoint = (serverRelativeUrl) => toRequestUrl(serverRelativeUrl);

/**
 * Ensures a full SharePoint folder path exists (creates missing folders in order).
 */
export const ensureSharePointFolderHierarchy = async (folderServerRelativeUrl, digest = null) => {
    const normalizedFolder = normalizeServerRelativeUrl(folderServerRelativeUrl);
    if (!normalizedFolder) {
        throw new Error('ensureSharePointFolderHierarchy expects a valid folder URL');
    }

    const { siteRoot, folderSegments } = buildFolderCreationPlan(normalizedFolder);
    if (folderSegments.length === 0) return;

    const digestValue = digest || await getRequestDigest(siteRoot);
    let currentPath = siteRoot || '';

    for (const segment of folderSegments) {
        currentPath = `${currentPath}/${segment}`;
        await ensureSharePointFolder(currentPath, digestValue, siteRoot);
    }
};

/**
 * Creates a SharePoint file only if it does not exist (no overwrite).
 * Uses direct GET/PUT flow with credentials include.
 */
export const ensureSharePointTextFileExists = async ({
    serverRelativeUrl,
    text,
    contentType = 'text/plain; charset=utf-8',
    digest = null,
}) => {
    if (typeof text !== 'string') {
        throw new Error('ensureSharePointTextFileExists expects "text" as a string');
    }

    const { requestUrl, fileServerRelativeUrl, folderServerRelativeUrl } = splitServerRelativeFileUrl(serverRelativeUrl);

    const readResponse = await fetch(requestUrl, {
        method: 'GET',
        credentials: 'include',
        headers: {
            'Content-Type': 'text/plain',
        },
    });

    if (readResponse.ok) {
        return { created: false, response: readResponse };
    }

    if (readResponse.status !== 404) {
        const readError = summarizeErrorText(await responseTextSafe(readResponse));
        throw new Error(`SharePoint read failed (${readResponse.status}): ${readError}`);
    }

    spLog.warn(`קובץ לא קיים, מנסה ליצור ישירות: ${fileServerRelativeUrl}`);

    const createResponse = await putTextFile(requestUrl, text, contentType);
    if (createResponse.ok) {
        spLog.success(`נוצר קובץ התחלתי: ${fileServerRelativeUrl}`);
        return { created: true, response: createResponse };
    }

    // If parent folders are missing, try creating hierarchy once, then retry PUT.
    if (createResponse.status === 404) {
        const siteRoot = resolveApiSiteRoot(fileServerRelativeUrl);
        const digestValue = digest || await getRequestDigest(siteRoot);
        await ensureSharePointFolderHierarchy(folderServerRelativeUrl, digestValue);

        const retryResponse = await putTextFile(requestUrl, text, contentType);
        if (retryResponse.ok) {
            spLog.success(`נוצר קובץ התחלתי לאחר יצירת תיקיות: ${fileServerRelativeUrl}`);
            return { created: true, response: retryResponse };
        }

        const retryError = summarizeErrorText(await responseTextSafe(retryResponse));
        throw new Error(`SharePoint create file failed (${retryResponse.status}): ${retryError}`);
    }

    const createError = summarizeErrorText(await responseTextSafe(createResponse));
    throw new Error(`SharePoint create file failed (${createResponse.status}): ${createError}`);
};

/**
 * Saves text content into a SharePoint file.
 * Direct PUT first; only if parent path is missing (404), tries creating folders then retries.
 */
export const upsertSharePointTextFile = async ({
    serverRelativeUrl,
    text,
    contentType = 'text/plain; charset=utf-8',
    digest = null,
}) => {
    if (typeof text !== 'string') {
        throw new Error('upsertSharePointTextFile expects "text" as a string');
    }

    const { requestUrl, fileServerRelativeUrl, folderServerRelativeUrl } = splitServerRelativeFileUrl(serverRelativeUrl);

    const saveResponse = await putTextFile(requestUrl, text, contentType);
    if (saveResponse.ok) {
        const created = saveResponse.status === 201;
        return { created, response: saveResponse };
    }

    // Most common missing-file/folder case in bootstrapping.
    if (saveResponse.status === 404) {
        spLog.warn(`קובץ/תיקייה חסרים, מנסה להקים נתיב ואז לשמור: ${fileServerRelativeUrl}`);
        const siteRoot = resolveApiSiteRoot(fileServerRelativeUrl);
        const digestValue = digest || await getRequestDigest(siteRoot);
        await ensureSharePointFolderHierarchy(folderServerRelativeUrl, digestValue);

        const retryResponse = await putTextFile(requestUrl, text, contentType);
        if (retryResponse.ok) {
            return { created: true, response: retryResponse };
        }

        const retryError = summarizeErrorText(await responseTextSafe(retryResponse));
        throw new Error(`SharePoint save failed after folder ensure (${retryResponse.status}): ${retryError}`);
    }

    const saveError = summarizeErrorText(await responseTextSafe(saveResponse));
    throw new Error(`SharePoint save failed (${saveResponse.status}): ${saveError}`);
};

/**
 * Gets a SharePoint Request Digest token, with per-site caching.
 * @param {string} [scope=''] Optional site root or any URL/path under target site.
 * @returns {Promise<string>}
 */
export const getRequestDigest = async (scope = '') => {
    const siteRoot = resolveApiSiteRoot(scope);
    const cacheKey = siteRoot || ROOT_CACHE_KEY;
    const now = Date.now();
    const cached = requestDigestCache.get(cacheKey);

    if (cached && now - cached.time < CACHE_EXPIRATION_MS) {
        spLogDigestCache(true);
        return cached.value;
    }

    const endpoint = buildSiteApiUrl(siteRoot, '/_api/contextinfo');

    try {
        spLogDigestCache(false);

        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                Accept: ODATA_ACCEPT,
                'Content-Type': ODATA_CONTENT_TYPE,
            },
            credentials: 'include',
        });

        spLog.file(`תגובת contextinfo | status: ${response.status} ${response.statusText}`);
        if (!response.ok) {
            const body = summarizeErrorText(await responseTextSafe(response));
            throw new Error(`HTTP error! status: ${response.status}. ${body}`);
        }

        const data = await response.json();
        const digest = data?.d?.GetContextWebInformation?.FormDigestValue || '';
        requestDigestCache.set(cacheKey, { value: digest, time: now });
        spLog.success('Request Digest התקבל בהצלחה');
        return digest;
    } catch (error) {
        spLog.error('שגיאה בקבלת Request Digest:', error);
        throw error;
    }
};

/**
 * Creates a backup folder and copies data files into it.
 */
export const createBackup = async (filesToBackup = []) => {
    try {
        spLog.boot('מתחיל גיבוי מערכת ל-SharePoint...');

        if (!filesToBackup || filesToBackup.length === 0) {
            filesToBackup = [
                SHAREPOINT_CONFIG.fileServerRelativeUrl,
                SHAREPOINT_CONFIG.navFileServerRelativeUrl,
                SHAREPOINT_CONFIG.siteContentFileServerRelativeUrl,
                SHAREPOINT_CONFIG.themeFileServerRelativeUrl,
                SHAREPOINT_CONFIG.widgetsFileServerRelativeUrl,
                SHAREPOINT_CONFIG.externalLinksFileServerRelativeUrl,
                SHAREPOINT_CONFIG.usersFileServerRelativeUrl,
            ];
        }

        const firstFilePath = toPathname(filesToBackup[0]);
        const { siteRoot } = extractSiteRootFromPath(firstFilePath);
        if (!siteRoot) {
            spLog.error('לא ניתן לזהות נתיב אתר מתוך', firstFilePath);
            return false;
        }

        const backupBaseFolder = `${SHAREPOINT_PATHS.siteAssetsRoot}/Backups`;
        const now = new Date();
        const timestamp = now.toISOString().replace(/[:.]/g, '-').slice(0, 19);
        const backupFolderName = `backup-${timestamp}`;
        const targetFolderPath = `${backupBaseFolder}/${backupFolderName}`;

        await ensureSharePointFolderHierarchy(targetFolderPath);
        spLog.file(`תיקיית גיבוי נוצרה/אומתה: ${targetFolderPath}`);

        for (const filePath of filesToBackup) {
            try {
                const sourceEndpoint = buildFileValueEndpoint(filePath);
                spLog.file(`גיבוי: קורא מקור | ${sourceEndpoint}`);

                const readRes = await fetch(sourceEndpoint, {
                    method: 'GET',
                    credentials: 'include',
                    headers: { 'Content-Type': 'text/plain' },
                });

                if (!readRes.ok) {
                    if (readRes.status === 404) {
                        spLog.warn(`קובץ לא נמצא לגיבוי (מדלג): ${filePath}`);
                        continue;
                    }
                    const readErr = summarizeErrorText(await responseTextSafe(readRes));
                    throw new Error(`שגיאה בקריאת קובץ לגיבוי (${readRes.status}): ${readErr}`);
                }

                const fileContent = await readRes.text();
                const fileName = toPathname(filePath).split('/').pop();
                if (!fileName) continue;

                const targetFilePath = `${targetFolderPath}/${fileName}`;
                const { response: writeRes } = await upsertSharePointTextFile({
                    serverRelativeUrl: targetFilePath,
                    text: fileContent,
                    contentType: 'text/plain; charset=utf-8',
                });

                if (!writeRes.ok) {
                    spLog.error(`שגיאה בכתיבת קובץ גיבוי ${fileName}:`, writeRes.status);
                } else {
                    spLog.success(`הועתק לגיבוי: ${fileName}`);
                }
            } catch (fileErr) {
                spLog.error(`שגיאה בגיבוי קובץ ${filePath}:`, fileErr);
            }
        }

        spLog.success('גיבוי הושלם בהצלחה');
        return true;
    } catch (error) {
        spLog.error('שגיאה בתהליך הגיבוי:', error);
        return false;
    }
};

/**
 * Uploads an image file. In mock mode, converts to Base64 data URL.
 * In production, uploads to SharePoint under IMAGE_BASE_FOLDER/<categoryFolder>.
 */
export const uploadImage = async (file, categoryFolder) => {
    if (!file) throw new Error('לא סופק קובץ להעלאה');

    if (SHAREPOINT_CONFIG.useMock) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    let width = img.width;
                    let height = img.height;
                    const MAX_SIZE = 400;

                    if (width > height) {
                        if (width > MAX_SIZE) {
                            height *= MAX_SIZE / width;
                            width = MAX_SIZE;
                        }
                    } else if (height > MAX_SIZE) {
                        width *= MAX_SIZE / height;
                        height = MAX_SIZE;
                    }

                    canvas.width = width;
                    canvas.height = height;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);
                    resolve(canvas.toDataURL('image/webp', 0.6));
                };
                img.onerror = () => reject(new Error('שגיאה בטעינת התמונה לדחיסה'));
                img.src = e.target.result;
            };
            reader.onerror = () => reject(new Error('שגיאה בקריאת הקובץ'));
            reader.readAsDataURL(file);
        });
    }

    const targetFolder = `${normalizeServerRelativeUrl(IMAGE_BASE_FOLDER)}/${String(categoryFolder || '').trim()}`;
    const siteUrl = resolveApiSiteRoot(targetFolder);
    spLog.file(`מעלה תמונה ל-SharePoint | תיקייה: ${targetFolder} | קובץ: ${file.name}`);

    const digest = await getRequestDigest(siteUrl);
    await ensureSharePointFolderHierarchy(targetFolder, digest);

    const arrayBuffer = await file.arrayBuffer();
    const escapedFolder = targetFolder.replace(/'/g, "''");
    const encodedFileName = encodeURIComponent(file.name).replace(/'/g, '%27');
    const uploadUrl =
        `${buildSiteApiUrl(siteUrl, '')}/_api/web/GetFolderByServerRelativeUrl('${escapedFolder}')/Files/add(url='${encodedFileName}',overwrite=true)`;

    const uploadRes = await fetch(uploadUrl, {
        method: 'POST',
        credentials: 'include',
        headers: {
            Accept: ODATA_ACCEPT,
            'X-RequestDigest': digest,
        },
        body: arrayBuffer,
    });

    spLog.file(`תגובת העלאת תמונה | status: ${uploadRes.status} ${uploadRes.statusText}`);
    if (!uploadRes.ok) {
        const errorText = summarizeErrorText(await responseTextSafe(uploadRes));
        throw new Error(`העלאת תמונה נכשלה (${uploadRes.status}): ${errorText}`);
    }

    const data = await uploadRes.json();
    const url = data?.d?.ServerRelativeUrl;
    spLog.success(`העלאת תמונה הצליחה | נתיב: ${url}`);
    return url;
};
